import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class MessageInputField extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return Container(
      padding:EdgeInsets.symmetric(horizontal: 8.0),
      color: Colors.white,
      child: Row(children: [
        IconButton(onPressed: (){}, icon: Icon(Icons.attach_file),),
        Expanded(child: TextField(decoration: InputDecoration(hintText: 'Type a message here...',border:
        InputBorder.none),),),
        IconButton(onPressed: (){}, icon:Icon(Icons.mic)),
      ],),
    );
  }
}