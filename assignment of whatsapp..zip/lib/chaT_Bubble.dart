import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class ChatBubble extends StatelessWidget{
  String text;
  bool isSender;
  String avatar;

  ChatBubble({required this.text,required this.isSender,required this.avatar});
  @override
  Widget build(BuildContext context) {
    return Padding(padding: EdgeInsets.all(8.0),
    child:Row(
      mainAxisAlignment: isSender ?MainAxisAlignment.end:MainAxisAlignment.start,
      children: [
        if(!isSender)
          CircleAvatar(
            backgroundImage: AssetImage(avatar),
          ),
        Container(decoration: BoxDecoration(color: isSender? Colors.green[100]:Colors.grey[300],
        borderRadius: BorderRadius.circular(10),),
        padding: EdgeInsets.all(10),
        margin: EdgeInsets.symmetric(horizontal: 10),
        child: Text(text),),
        if(isSender)
          CircleAvatar(backgroundImage: AssetImage(avatar),)
      ],
    ) ,);
  }
}