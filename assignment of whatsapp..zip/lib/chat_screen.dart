import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'chaT_Bubble.dart';
import 'messageinput.dart';

class ChatScreen extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title:Row(children: [
          CircleAvatar(backgroundImage: AssetImage('assets/images/person.jpg'),),
          SizedBox(width: 10,),Text('Person')
        ],),
        actions: [
          IconButton(onPressed: (){}, icon: Icon(Icons.videocam),),
          IconButton(onPressed: (){}, icon: Icon(Icons.call),),
          IconButton(onPressed: (){}, icon: Icon(Icons.more_vert),),
        ],
      ),
      body: Stack(children: [
        Container(
          decoration: BoxDecoration(image:DecorationImage(
            image: AssetImage('assets/images/background.png'),
          fit: BoxFit.cover,),
          ),
        ),
        Column(
          children: [
            Expanded(child: ListView(
              children: [
                ChatBubble(text:'This is My First Message',isSender:true,avatar:'assets/images/person1.jpg'),
                ChatBubble(text:'This is My Second Message',isSender:false,avatar:'assets/images/person2.jpg'),
              ],
            ),
            ),
            MessageInputField(),
          ],
        )
      ]),
    );
  }
}