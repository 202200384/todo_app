import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:new_app/post_widget.dart';
import 'package:new_app/storywidget.dart';

class HomeScreen extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return Scaffold(appBar: AppBar(title: Text('Facebook Home'),
    actions: [
      IconButton(onPressed: (){}, icon: Image.asset('assets/images/facebookStory.jpg'),),

    ],),
    body: ListView(
      children: [
        StoryWidget(),
        PostWidget(
          username:'User 1',
          postContent:'This is the first post!',
        ),
        PostWidget(
          username:'User 2',
          postContent:'welcome you!'
        ),
      ],
    ),
    );
  }
}