import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'homescreen.dart';

class LoginScreen extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return Scaffold(appBar: AppBar(
      title: Text('Facebook Login'),
    ),
    body: Padding(padding: EdgeInsets.all(16.0),child: Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        TextField(decoration: InputDecoration(labelText: 'Enter Email or phone'),
        ),
        TextField(
          decoration: InputDecoration(labelText: 'Password'),
          obscureText: true,
        ),
        SizedBox(height: 20,),ElevatedButton(onPressed: (){
          Navigator.push(context, MaterialPageRoute(builder: (context)=>HomeScreen()),);
        }, child: Text('Log In'),)
      ],
    ),),
    );

  }
}