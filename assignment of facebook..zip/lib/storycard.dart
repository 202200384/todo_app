import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class StoryCard extends StatelessWidget{
  String username;
  StoryCard({required this.username});
  @override
  Widget build(BuildContext context) {
    return Container(
      width: 80,
      margin: EdgeInsets.symmetric(horizontal: 5.0),
      child: Column(children: [
       CircleAvatar(radius: 30,
       backgroundImage: AssetImage('assets/images/facebookStory.jpg'),),
        SizedBox(height: 5,),
        Text(username,overflow: TextOverflow.ellipsis),
      ]),
    );
  }
}