import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class PostWidget extends StatelessWidget{
  String username;
  String postContent;
  
  PostWidget({required this.username,required this.postContent});
  @override
  Widget build(BuildContext context) {
    return Card(margin: EdgeInsets.all(10.0),
      child: Padding(padding: EdgeInsets.all(10.0),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            CircleAvatar(backgroundImage: AssetImage('assets/images/facebookStory.jpg'),),
            SizedBox(width: 10,),
            Text(postContent),
            SizedBox(height: 10,),
            Row(
              children: [
                IconButton(onPressed: (){}, icon: Image.asset('assets/images/like.jpg')),
                IconButton(onPressed: (){}, icon: Image.asset('assets/images/comment.jpg')),
                IconButton(onPressed: (){}, icon: Image.asset('assets/images/share.png')),
              ],
            ),
            Row(
              children: [
                Image.asset('assets/images/singleLike.jpg',width: 14,height: 14,color: Colors.blue,),SizedBox(
                  width: 5,
                ),
                Text('1000 Likes')
              ],
            )
          ],
        )
      ]),),
    );
  }
}
