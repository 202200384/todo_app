import 'package:flutter/material.dart';

import 'loginscreen.dart';

void main(){
  runApp(Facebook());
}
class Facebook extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Facebook',
      home: LoginScreen(),
    );
  }
}