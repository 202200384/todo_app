import 'package:flutter/cupertino.dart';
import 'package:new_app/storycard.dart';

class StoryWidget extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return Container(
      height: 100,
      margin: EdgeInsets.all(10.0),
      child: ListView(
        scrollDirection: Axis.horizontal,
        children: [
          StoryCard(username:'User 1',),
          StoryCard(username:'User 2',),
        ],
      ),
    );
  }
}